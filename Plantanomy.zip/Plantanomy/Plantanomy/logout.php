<?php

session_start();
session_unset();

echo 'echo "<script>location.href="index.php"</script>"'


?>
